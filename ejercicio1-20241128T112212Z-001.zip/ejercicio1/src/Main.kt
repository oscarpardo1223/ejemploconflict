fun main() {
    println("Ejercicio 1, calcula el área y el perímetro de un cuadrado.")
    println("Adjunta la medida del lado del cuadrado en cm")
    var l:Int= readln().toInt()
    print("La superficie del cuadrado es ${l *l}")
    print(l * l)
    println(" El perímetro del cuadrado es ")
    print(l * 4)
}